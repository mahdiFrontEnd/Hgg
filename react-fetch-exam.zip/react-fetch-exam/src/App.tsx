import { useEffect, useRef, useState, type FormEvent } from 'react';
import { errorMessage, setAccessToken } from './api/client';
import { itemsApi, type Item } from './api/items';
export default function App() {
  const [items, setItems] = useState<Item[]>([]);
  const [name, setName] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [pending, setPending] = useState(false);
  const [token, setToken] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [revision, setRevision] = useState(0);
  const busy = useRef(false);
  const disabled = loading || pending;
  useEffect(() => {
    const controller = new AbortController();
    setLoading(true); setError(null);
    void itemsApi.list(search, controller.signal)
      .then(data => { if (!controller.signal.aborted) setItems(data); })
      .catch((reason: unknown) => { if (!controller.signal.aborted) setError(errorMessage(reason)); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [search, revision]);
  function clearEditor() { setName(''); setEditingId(null); }
  async function mutate(action: () => Promise<void>) {
    if (busy.current || loading) return;
    busy.current = true; setPending(true); setError(null);
    try { await action(); } catch (reason) { setError(errorMessage(reason)); }
    finally { busy.current = false; setPending(false); }
  }
  function save(event: FormEvent) {
    event.preventDefault();
    const value = name.trim();
    if (!value) { setError('نام آیتم را وارد کنید.'); return; }
    void mutate(async () => {
      if (editingId === null) {
        const item = await itemsApi.create(value);
        setItems(previous => [...previous, item]);
      } else {
        const item = await itemsApi.update(editingId, value);
        setItems(previous => previous.map(old => old.id === editingId ? item : old));
      }
      clearEditor();
      // Reload to keep server-side filtering authoritative after a mutation.
      setRevision(previous => previous + 1);
    });
  }
  function remove(id: number) {
    void mutate(async () => {
      await itemsApi.remove(id);
      setItems(previous => previous.filter(item => item.id !== id));
      if (editingId === id) clearEditor();
      setRevision(previous => previous + 1);
    });
  }
  return <main>
    <h1>مدیریت آیتم‌ها</h1><p>React 19 · TypeScript · Fetch</p>
    <form onSubmit={event => {
      event.preventDefault(); setAccessToken(token); clearEditor();
      setItems([]); setRevision(previous => previous + 1);
    }}>
      <label htmlFor="token">توکن دسترسی</label>
      <input id="token" type="password" value={token} onChange={event => setToken(event.target.value)} disabled={disabled} autoComplete="off" />
      <button disabled={disabled}>اعمال توکن و بارگذاری</button>
    </form>
    <form onSubmit={event => { event.preventDefault(); setSearch(searchInput); setRevision(previous => previous + 1); }}>
      <label htmlFor="search">جست‌وجو</label>
      <input id="search" value={searchInput} onChange={event => setSearchInput(event.target.value)} disabled={disabled} />
      <button disabled={disabled}>جست‌وجو</button>
    </form>
    {loading && <p role="status">در حال بارگذاری…</p>}
    {pending && <p role="status">در حال ذخیره تغییرات…</p>}
    {error && <p role="alert" className="error">{error}</p>}
    <button disabled={disabled} onClick={() => setRevision(previous => previous + 1)}>بارگذاری مجدد</button>
    <ul aria-busy={disabled}>{items.map(item => <li key={item.id}>
      <span>{item.name}</span>
      <button disabled={disabled} onClick={() => { setEditingId(item.id); setName(item.name); }}>ویرایش</button>
      <button disabled={disabled} onClick={() => remove(item.id)}>حذف</button>
    </li>)}</ul>
    {!disabled && !error && items.length === 0 && <p>آیتمی وجود ندارد.</p>}
    <form onSubmit={save}>
      <label htmlFor="name">{editingId === null ? 'نام آیتم جدید' : 'ویرایش نام آیتم'}</label>
      <input id="name" value={name} onChange={event => setName(event.target.value)} disabled={disabled} required />
      <button disabled={disabled || !name.trim()}>{editingId === null ? 'افزودن' : 'ذخیره'}</button>
      {editingId !== null && <button type="button" disabled={disabled} onClick={clearEditor}>انصراف</button>}
    </form>
  </main>;
}
