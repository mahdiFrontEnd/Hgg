import { afterEach, describe, expect, it, vi } from 'vitest';
import { ApiError, request, setAccessToken } from './client';
import { itemsApi } from './items';
afterEach(() => { vi.unstubAllGlobals(); setAccessToken(null); });
function mockResponse(body: string | null, status = 200, contentType = 'application/json') {
  const mock = vi.fn().mockResolvedValue(new Response(body, { status, headers: { 'Content-Type': contentType } }));
  vi.stubGlobal('fetch', mock); return mock;
}
describe('Fetch client', () => {
  it('encodes Persian and reserved query characters and skips null values', async () => {
    const fetchMock = mockResponse('[]');
    await request('items', { query: { search: 'نام & + /', page: 0, active: false, ignored: null } });
    const url = fetchMock.mock.calls[0][0] as URL;
    expect(url.pathname).toBe('/api/items');
    expect(url.searchParams.get('search')).toBe('نام & + /');
    expect(url.searchParams.get('page')).toBe('0');
    expect(url.searchParams.get('active')).toBe('false');
    expect(url.searchParams.has('ignored')).toBe(false);
  });
  it('adds bearer token and JSON headers and preserves custom headers', async () => {
    const fetchMock = mockResponse('{"id":1,"name":"فارسی"}');
    setAccessToken('real-token');
    await request('items', { method: 'POST', json: { name: 'فارسی' }, headers: { 'X-Request-ID': '123' } });
    const options = fetchMock.mock.calls[0][1] as RequestInit;
    const headers = new Headers(options.headers);
    expect(headers.get('Authorization')).toBe('Bearer real-token');
    expect(headers.get('Content-Type')).toBe('application/json; charset=utf-8');
    expect(headers.get('X-Request-ID')).toBe('123');
    expect(options.body).toBe(JSON.stringify({ name: 'فارسی' }));
  });
  it('handles DELETE 204 without parsing JSON', async () => {
    const fetchMock = mockResponse(null, 204);
    await expect(itemsApi.remove(5)).resolves.toBeUndefined();
    expect(fetchMock.mock.calls[0][1].method).toBe('DELETE');
  });
  it('preserves HTTP status and server error message', async () => {
    mockResponse('{"message":"Unauthorized"}', 401);
    await expect(request('items')).rejects.toMatchObject({ status: 401, message: 'Unauthorized' });
  });
  it('reports HTTP errors even when error JSON is malformed', async () => {
    mockResponse('{broken', 500);
    await expect(request('items')).rejects.toMatchObject({ status: 500 });
  });
  it('rejects malformed successful JSON', async () => {
    mockResponse('{broken');
    await expect(request('items')).rejects.toBeInstanceOf(ApiError);
  });
  it('rejects unexpected response shapes', async () => {
    mockResponse('{"items":[]}');
    await expect(itemsApi.list('', new AbortController().signal)).rejects.toThrow('ساختار');
  });
  it('forwards AbortSignal and network failures', async () => {
    const controller = new AbortController();
    const failure = new TypeError('network');
    const fetchMock = vi.fn().mockRejectedValue(failure);
    vi.stubGlobal('fetch', fetchMock);
    await expect(request('items', { signal: controller.signal })).rejects.toBe(failure);
    expect(fetchMock.mock.calls[0][1].signal).toBe(controller.signal);
  });
  it('sends PUT with the encoded resource path and validates item data', async () => {
    const fetchMock = mockResponse('{"id":7,"name":"updated"}');
    await expect(itemsApi.update(7, 'updated')).resolves.toEqual({ id: 7, name: 'updated' });
    expect((fetchMock.mock.calls[0][0] as URL).pathname).toBe('/api/items/7');
    expect(fetchMock.mock.calls[0][1].method).toBe('PUT');
  });
});
