# پاسخ آزمون React 19 + TypeScript + Fetch

## اجرای پروژه

نیازمندی: Node.js نسخه 22.12 یا بالاتر.

```bash
npm ci
```

از `.env.example` یک کپی با نام `.env.local` بسازید و آدرس واقعی API را وارد کنید:

```dotenv
VITE_API_BASE_URL=https://your-server.com/api/
```

```bash
npm run dev
npm run build
npm test
```

آدرس example.com در صورت سؤال صرفاً نمونه است و API واقعی آیتم‌ها نیست. توکن معتبر را در فرم وارد و اعمال کنید؛ در پروژه واقعی `setAccessToken` پس از login فراخوانی می‌شود. توکن در حافظه نگهداری می‌شود و با refresh پاک می‌شود. هیچ توکن واقعی یا fake-token در کد hardcode نشده است. تنظیم CORS بر عهده سرور است.

## قرارداد API فرض‌شده

| عملیات | مسیر | ورودی | پاسخ موفق |
| --- | --- | --- | --- |
| GET | items?search=... | پارامتر search اختیاری | آرایه `{id: number, name: string}` |
| POST | items | JSON با فیلد name | آیتم ساخته‌شده |
| PUT | items/:id | JSON با فیلد name | آیتم ویرایش‌شده |
| DELETE | items/:id | بدون body | پاسخ خالی 204 یا پاسخ موفق دیگر |

نام پارامتر جست‌وجو و ساختار پاسخ بر اساس اطلاعات محدود سؤال فرض شده‌اند. اگر API واقعی از envelope مانند `{data: [...]}` یا پاسخ خالی PUT استفاده کند، فایل items.ts باید مطابق قرارداد آن تغییر کند. این پروژه backend یا سیستم login ندارد.

## ساختار و تصمیم‌ها

- `src/main.tsx`: راه‌اندازی با createRoot و StrictMode.
- `src/api/client.ts`: ساخت URL، URLSearchParams، هدرها، Bearer Token، JSON و خطاهای HTTP.
- `src/api/items.ts`: چهار endpoint و اعتبارسنجی runtime پاسخ‌ها؛ TypeScript به‌تنهایی JSON خارجی را اعتبارسنجی نمی‌کند.
- `src/App.tsx`: loading مستقل از mutation، فرم ویرایش مستقل، جلوگیری از درخواست تکراری، functional state updates و AbortController برای GET.
- `src/api/client.test.ts`: تست خطاهای HTTP، پاسخ 204، encoding، header، PUT، ساختار نامعتبر و signal.

fetch برای 4xx/5xx به‌صورت خودکار reject نمی‌شود؛ response.ok بررسی می‌شود. پاسخ DELETE خالی بدون res.json مدیریت می‌شود. نام فارسی در JSON و متن‌ها UTF-8 است؛ query و بخش id مسیر با ابزار مناسب encode می‌شوند، نه با encode کردن کل URL. درخواست لغوشده خطایی در UI نمایش نمی‌دهد و نتیجه قدیمی state را بازنویسی نمی‌کند. پس از mutation لیست دوباره خوانده می‌شود تا فیلتر سمت سرور معتبر بماند.

createRoot از React 18 معرفی شده و در React 19 نیز API صحیح راه‌اندازی است؛ جدیدِ اختصاصی React 19 نیست.

## ایرادهای کد اولیه

1. بررسی نشدن response.ok.
2. استفاده از res.json برای حذف با پاسخ خالی.
3. توکن و base URL ثابت در کامپوننت.
4. نبود مدیریت query و encoding.
5. استفاده از state بسته‌شده در closure به‌جای functional updates.
6. نبود cleanup و لغو GET در useEffect.
7. نبود loading برای تغییرات و امکان ارسال تکراری.
8. استفاده از یک مقدار newItem برای افزودن و ویرایش بدون انتخاب روشن آیتم.
9. اعتبارسنجی نشدن ورودی و پاسخ API.

مراجع: https://react.dev/reference/react-dom/client/createRoot و https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
