import { request } from './client';
export interface Item { id: number; name: string }
function isItem(value: unknown): value is Item {
  return typeof value === 'object' && value !== null && 'id' in value &&
    typeof value.id === 'number' && Number.isFinite(value.id) && 'name' in value && typeof value.name === 'string';
}
function parseItem(value: unknown): Item {
  if (!isItem(value)) throw new Error('ساختار پاسخ آیتم معتبر نیست.');
  return value;
}
const itemPath = (id: number) => `items/${encodeURIComponent(String(id))}`;
export const itemsApi = {
  async list(search: string, signal: AbortSignal): Promise<Item[]> {
    const data = await request('items', { query: { search: search.trim() || undefined }, signal });
    if (!Array.isArray(data) || !data.every(isItem)) throw new Error('ساختار پاسخ لیست معتبر نیست.');
    return data;
  },
  async create(name: string): Promise<Item> {
    return parseItem(await request('items', { method: 'POST', json: { name } }));
  },
  async update(id: number, name: string): Promise<Item> {
    return parseItem(await request(itemPath(id), { method: 'PUT', json: { name } }));
  },
  async remove(id: number): Promise<void> { await request(itemPath(id), { method: 'DELETE' }); },
};
