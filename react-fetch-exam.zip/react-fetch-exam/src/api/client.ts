export class ApiError extends Error {
  constructor(message: string, public readonly status: number, public readonly details: unknown) {
    super(message); this.name = 'ApiError';
  }
}
type QueryValue = string | number | boolean | null | undefined;
type Options = Omit<RequestInit, 'body' | 'method'> & {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  query?: Record<string, QueryValue>;
  json?: unknown;
};
let accessToken: string | null = null;
// Set after login. Do not put tokens in source code or VITE variables.
export function setAccessToken(token: string | null) { accessToken = token?.trim() || null; }
export async function request(path: string, options: Options = {}): Promise<unknown> {
  const base = import.meta.env.VITE_API_BASE_URL || 'https://example.com/api/';
  const url = new URL(path, base.endsWith('/') ? base : `${base}/`);
  const { query, json, headers: customHeaders, ...init } = options;
  for (const [key, value] of Object.entries(query ?? {})) {
    if (value != null) url.searchParams.set(key, String(value));
  }
  const headers = new Headers(customHeaders);
  if (!headers.has('Accept')) headers.set('Accept', 'application/json');
  if (accessToken) headers.set('Authorization', `Bearer ${accessToken}`);
  if (json !== undefined) headers.set('Content-Type', 'application/json; charset=utf-8');
  const response = await fetch(url, { ...init, headers, body: json === undefined ? undefined : JSON.stringify(json) });
  const raw = response.status === 204 || response.status === 205 ? '' : await response.text();
  let data: unknown = raw || undefined;
  let invalidJson = false;
  const contentType = response.headers.get('Content-Type') || '';
  if (raw && (contentType.includes('application/json') || contentType.includes('+json'))) {
    try { data = JSON.parse(raw); } catch { invalidJson = true; }
  }
  if (!response.ok) {
    const message = typeof data === 'object' && data !== null && 'message' in data && typeof data.message === 'string'
      ? data.message : `خطای سرور (${response.status})`;
    throw new ApiError(message, response.status, data);
  }
  if (invalidJson) throw new ApiError('پاسخ JSON سرور معتبر نیست.', response.status, raw);
  return data;
}
export function errorMessage(error: unknown): string {
  if (error instanceof ApiError) return error.message;
  if (error instanceof TypeError) return 'ارتباط با سرور برقرار نشد؛ شبکه، آدرس API و CORS را بررسی کنید.';
  return error instanceof Error ? error.message : 'خطای غیرمنتظره رخ داد.';
}
